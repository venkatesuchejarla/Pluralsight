package selflearning.digitalocean;

import org.junit.jupiter.api.*;

public class JUnitNested {
    @BeforeAll
    static void beforeAll() {
        System.out.println("Main Class -> Execute once before all methods");
    }
    @BeforeEach
    void beforeEach() {
        System.out.println("Main Class  -> Execute once before each method");
    }
    @AfterAll
    static void afterAll() {
        System.out.println("Main Class  -> Execute once after all methods");
    }
    @AfterEach
    void afterEach() {
        System.out.println("Main Class  -> Execute once after each method");
    }
    @Nested
    class Inner {
        @BeforeEach
        void beforeEach() {
            System.out.println("Inner Class -> Execute before each method");
        }
        @AfterEach
        void afterEach() {
            System.out.println("Inner Class -> Execute after each method");
        }
        @Test
        void method() {
            System.out.println("Inner class method executed");
        }
        @Nested
        class InnerMost {
            @BeforeEach

            void beforeEach() {
                System.out.println("Inner Most Class -> Execute before each method");
            }
            @AfterEach
            void afterEach() {
                System.out.println("Inner Most Class -> Execute after each method");
            }
            @Test
            void method() {
                System.out.println("Inner Most Class method executed");
            }
        }
    }
}
