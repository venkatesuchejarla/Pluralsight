package selflearning.digitalocean;

import org.junit.jupiter.api.*;

public class JUnit5Features {
    @BeforeAll
    static void beforeAll() {
        System.out.println("Execute once before all test methods in the class");
    }
    @BeforeEach
    void beforeEach() {
        System.out.println("Execute once before each test method");
    }
    @Test
    void testMethod1() {
        System.out.println("Test method1 is executed");
    }
    @DisplayName("Test method2 with condition")
    @Test
    void testMethod2() {
        System.out.println("Test method2 is executed");
    }
    @Test
    @Disabled
    void testMethod3() {
        System.out.println("Test method3 is disabled");
    }
    @AfterEach
    void afterEach() {
        System.out.println("Executed once after each test method");
    }
    @AfterAll
    static void afterAll() {
        System.out.println("Executed once after all test method");
    }

}
