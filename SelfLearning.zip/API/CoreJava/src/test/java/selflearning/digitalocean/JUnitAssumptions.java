package selflearning.digitalocean;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assumptions.*;

public class JUnitAssumptions {
    @Test
    void testAssumeTrue() {
        boolean b='A'=='A';
        assumeTrue(b);
        assertEquals("Hello","Hello");
    }
    @Test
    void testAssumeFalse() {
        boolean b=false;
        assumeFalse(b);
        assertEquals("Hello","Hello");
    }
    @Test
    void testAssumingThat() {
        System.setProperty("env","test");
        assumingThat("test".equals(System.getProperty("env")),
                ()->{assertEquals(10,10);
                System.out.println("perform below assertion only the test env");});
        assertEquals(20,20);
        System.out.println("Perform below assertions on all env");
    }
}
