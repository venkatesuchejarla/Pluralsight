package selflearning.digitalocean;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class JUnitAssertions {
    @Test
    void testAssertEqual() {
        assertEquals("ABC","ABC");
        assertEquals(20,20,"Optional assertion message");
        assertEquals(2+2,4);
    }
    @Test
    void testAssertFalse() {
        assertFalse("Name".length()==10);
        assertFalse(10>20,"Assertion Message");
    }
    @Test
    void testAssertNull() {
        assertNotNull("Venkatesu");
        assertNull(null);
    }
    @Test
    void testAssertAll() {
        String s1="Venkatesu";
        String s2="Mahi";
        String s3="Jahn";
        assertAll("numbers",
                ()->assertEquals(s1,"Venkatesu"),
                ()->assertEquals(s2,"Mahi"),
                ()->assertEquals(s3,"Jahn"));
    }
    @Test
    void testAssertTrue() {
        assertTrue(10==10);
    }
}
