package selflearning.baeldung;

import org.apache.logging.log4j.util.Strings;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;

import java.time.Month;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class JUnitParameterizedTest {
    public static boolean isOdd(int numbers) {
        return numbers %2 !=0;
    }
    public static boolean isBlank(String input) {
        return input==null || input.trim().isEmpty();
    }
    @ParameterizedTest
    @ValueSource(ints = {1,3,5,-5,15,Integer.MAX_VALUE})
    void isOddTest(int number) {
        assertTrue(JUnitParameterizedTest.isOdd(number));
    }

    @ParameterizedTest
    @ValueSource(strings={" ","    "})
    void isBlankTest(String input) {
        assertTrue(JUnitParameterizedTest.isBlank(input));
    }
    @ParameterizedTest
    @NullSource
    void isBlankTestNullSource(String input) {
        assertTrue(JUnitParameterizedTest.isBlank(input));
    }
    @ParameterizedTest
    @EmptySource
    void isBlackTestEmptySource(String input) {
        assertTrue(JUnitParameterizedTest.isBlank(input));
    }

    @ParameterizedTest
    @EnumSource(Month.class)
    void getMonthValue(Month month) {
        int monthNumber=month.getValue();
        assertTrue(monthNumber>=1 && monthNumber<=12);
    }
    @ParameterizedTest
    @CsvSource({"test,TEST","jaVA,JAVA"})
    void toUpperCaseTest(String input, String expected) {
        String actualValue=input.toUpperCase();
        assertEquals(expected,actualValue);
    }
    @ParameterizedTest
    @MethodSource("provideStringsForIsBlank")
    void isBlackTestMethodSource(String input, boolean expected) {
        assertEquals(expected, Strings.isBlank(input));
    }
    private static Stream<Arguments> provideStringsForIsBlank() {
        return Stream.of(
                Arguments.of(null,true),
                Arguments.of("",true),
                Arguments.of(" ",true),
                Arguments.of("Not black",false)
        );
    }
}
