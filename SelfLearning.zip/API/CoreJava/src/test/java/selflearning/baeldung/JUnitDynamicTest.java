package selflearning.baeldung;

import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

import java.util.stream.Stream;

import static java.lang.System.in;
import static java.lang.System.out;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class JUnitDynamicTest {
    /*@TestFactory
    Stream<DynamicTest> translateDynamicTestFromStreams() {
        return in.stream().map(word->DynamicTest.dynamicTest("Test translate "+word,()->{
            int id=in.indexOf(word);
            assertEquals(out.get(id),tanslate(word));
        }));
    }*/
}
