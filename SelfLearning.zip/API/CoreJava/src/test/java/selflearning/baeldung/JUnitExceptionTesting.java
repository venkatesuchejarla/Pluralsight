package selflearning.baeldung;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class JUnitExceptionTesting {
    @Test
    void testException() {
        Throwable exception=assertThrows(UnsupportedOperationException.class,()-> {
            throw new UnsupportedOperationException("Not Supported");
        });
        assertEquals("Not Supported",exception.getMessage());
    }
}
