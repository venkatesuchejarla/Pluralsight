package selflearning.baeldung;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.SelectPackages;
import org.junit.platform.suite.api.Suite;
import selflearning.digitalocean.JUnit5Features;

@Suite
//@SelectPackages("selflearning.digitalocean")
@SelectClasses({JUnitExceptionTesting.class, JUnit5Features.class})
public class JUnitTestSuites {
}
