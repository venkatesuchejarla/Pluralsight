package org.selflearning.designpatterns.behavioural.command;

public class GFG {
    public static void main(String[] args) {
        SimpleRemoteController simpleRemoteController=new SimpleRemoteController();
        Light light=new Light();
        Stereo stereo=new Stereo();
    }
}
interface Command {
    public void execute();
}
class Light {
    public void on() {
        System.out.println("Light is ON");
    }
    public void off() {
        System.out.println("Light is OFF");
    }
}
class LightOnCommand implements Command {
    Light light;
    public LightOnCommand(Light light) {
        this.light=light;
    }
    @Override
    public void execute() {
        light.on();
    }
}
class LightOffCommand implements Command {
    Light light;
    public LightOffCommand(Light light) {
        this.light=light;
    }

    @Override
    public void execute() {
        light.off();
    }
}
class Stereo {
    public void on() {
        System.out.println("Stereo is ON");
    }
    public void Off() {
        System.out.println("Stereo is OFF");
    }
    public void setCD() {
        System.out.println("Stereo is Set for CD Input");
    }
    public void setDVD() {
        System.out.println("Stereo is Set for DVD Input");
    }
    public void setRadio() {
        System.out.println("Stereo is Set for Radio Input");
    }
    public void setVolume(int volume) {
        System.out.println("Stereo is set for volume is "+volume);
    }
}
class StereoOffCommand implements Command {
    Stereo stereo;
    public StereoOffCommand(Stereo stereo) {
        this.stereo=stereo;
    }

    @Override
    public void execute() {
        stereo.Off();
    }
}
class StereoCDCommand implements Command {
    Stereo stereo;
    public StereoCDCommand(Stereo stereo) {
        this.stereo=stereo;
    }
    @Override
    public void execute() {
        stereo.on();
        stereo.setCD();
        stereo.setVolume(11);
    }
}
class SimpleRemoteController {
    Command slot;
    public SimpleRemoteController () {

    }
    public void setCommand(Command command) {
        slot=command;
    }
    public void buttonWasPressed() {
        slot.execute();
    }
}
