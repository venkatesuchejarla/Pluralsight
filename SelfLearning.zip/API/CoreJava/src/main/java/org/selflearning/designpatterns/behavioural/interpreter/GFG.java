package org.selflearning.designpatterns.behavioural.interpreter;

public class GFG {
    public static void main(String[] args) {
        Expression person1=new TerminalExpression("Venkatesu");
        Expression person2=new TerminalExpression("Mahi");
        Expression isSingle=new ORExpression(person1, person2);
        Expression isCommitted=new ANDExpression(person1, person2);
        System.out.println(isSingle.interpreter("Venkatesu"));
        System.out.println(isSingle.interpreter("Mahi"));
        System.out.println(isSingle.interpreter("Jahn"));
        System.out.println(isCommitted.interpreter("Venkatesu,Mahi"));
    }
}
interface Expression {
    boolean interpreter(String con);
}
class TerminalExpression implements Expression {
    String data;
    public TerminalExpression(String data) {
        this.data=data;
    }

    @Override
    public boolean interpreter(String con) {
        if (con.contains(data))
            return true;

        else
            return false;
    }
}
class ORExpression implements Expression {
    Expression exp1;
    Expression exp2;
    public ORExpression(Expression exp1, Expression exp2) {
        this.exp1=exp1;
        this.exp2=exp2;
    }
    @Override
    public boolean interpreter(String con) {
        return exp1.interpreter(con) || exp2.interpreter(con);
    }
}
class ANDExpression implements Expression {
    Expression exp1;
    Expression exp2;
    public ANDExpression(Expression exp1, Expression exp2) {
        this.exp1=exp1;
        this.exp2=exp2;
    }
    @Override
    public boolean interpreter(String con) {
        return exp1.interpreter(con) && exp2.interpreter(con);
    }
}