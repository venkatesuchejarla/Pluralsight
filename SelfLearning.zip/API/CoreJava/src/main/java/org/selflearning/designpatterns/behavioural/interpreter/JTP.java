package org.selflearning.designpatterns.behavioural.interpreter;

class JTP {
    public static void main(String[] args) {

    }
}
interface Pattern {
    public String conversion(String exp);
}
