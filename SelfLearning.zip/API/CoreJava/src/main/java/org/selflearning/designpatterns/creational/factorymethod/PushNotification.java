package org.selflearning.designpatterns.creational.factorymethod;

public class PushNotification implements Notification {
    @Override
    public void notifyUser() {
        System.out.println("Sending notification by Push");
    }
}
