package org.selflearning.designpatterns.creational.singleton;

public class EmployeeSingleton {
    public static void main(String[] args) {
        Employee.getInstance().setName("Venkatesu");
        String employeeName=Employee.getInstance().getName();
        System.out.println(employeeName);
    }
}
class Employee {
    private static Employee employee;
    private Integer id;
    private String name;
    private Employee() {

    }
    public Employee(Integer id, String name) {
        this.id=id;
        this.name=name;
    }
    public static Employee getInstance() {
        if (employee==null){
            employee=new Employee();
        }
        return employee;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
