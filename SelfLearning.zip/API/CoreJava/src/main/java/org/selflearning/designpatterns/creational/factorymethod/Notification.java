package org.selflearning.designpatterns.creational.factorymethod;

public interface Notification {
    void notifyUser();
}
