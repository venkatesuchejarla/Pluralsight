package org.selflearning.designpatterns.creational.abstractfactory;

public interface Bank {
    String getBankName();
}
class HDFC implements Bank {

    @Override
    public String getBankName() {
        return "HDFC Bank";
    }
}
class SBI implements Bank {
    @Override
    public String getBankName() {
        return "SBI Bank";
    }
}
class ICICI implements Bank {

    @Override
    public String getBankName() {
        return "ICICI Bank";
    }
}
