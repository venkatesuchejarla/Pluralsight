package org.selflearning.designpatterns.structural.adapter;

import java.util.Arrays;

interface Bird {
    public void fly();
    public void makeSound();
}
class Parrot implements Bird {
    @Override
    public void fly() {
        System.out.println("Parrot is flying");
    }

    @Override
    public void makeSound() {
        System.out.println("Parrot making sound");
    }
}
interface Animal {
    public void makeSound();
}
class Tiger implements Animal {
    @Override
    public void makeSound() {
        System.out.println("Tiger is making sound");
    }
}
class BirdAdapter implements Animal {
    Bird bird;
    public BirdAdapter(Bird bird) {
        this.bird=bird;
    }
    @Override
    public void makeSound() {
        bird.makeSound();
    }
}
class Main {
    public static void main(String[] args) {
        Parrot parrot=new Parrot();
        Animal animal=new Tiger();
        Animal birdAdapter=new BirdAdapter(parrot);
        System.out.println("Parrot...");
        parrot.fly();
        parrot.makeSound();
        System.out.println("Animal...");
        animal.makeSound();
        System.out.println("Birds Adapter....");
        birdAdapter.makeSound();
    }
}