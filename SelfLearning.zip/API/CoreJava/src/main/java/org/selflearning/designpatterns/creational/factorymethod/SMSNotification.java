package org.selflearning.designpatterns.creational.factorymethod;

public class SMSNotification implements Notification {
    public void notifyUser() {
        System.out.println("Sending notification by SMS");
    }
}
