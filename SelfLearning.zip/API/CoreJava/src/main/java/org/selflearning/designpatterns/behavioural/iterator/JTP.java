package org.selflearning.designpatterns.behavioural.iterator;

public class JTP {
    public static void main(String[] args) {
        CollectionOfNames collectionOfNames=new CollectionOfNames();
        for (Iterator iterator=collectionOfNames.getIterator(); iterator.hasNext();) {
            String name=(String) iterator.next();
            System.out.println(name);
        }
    }
}
interface Iterator {
    boolean hasNext();
    Object next();
}
interface Container {
    Iterator getIterator();
}
class CollectionOfNames implements Container {
    String names[]={"Venkatesu","Mahi","Jahn"};
    public Iterator getIterator() {
        return new CollectionNamesIterate();
    }
    class CollectionNamesIterate implements Iterator {
        int i;

        @Override
        public boolean hasNext() {
            if(i< names.length) {
                return true;
            }
            return false;
        }
        public Object next() {
            if (this.hasNext()) {
                return names[i++];
            }
            return null;
        }
    }
}
