package org.selflearning.designpatterns.creational.singleton;
//a class can have only one instance and providing global access to it.
//Advantage is only one object is created and reused many times
//two types early instantiation and lazy instantiation
//static member-it gets the memory only one time, it contains the instance of the singleton class
//private constructor-it prevents to instantiate the singleton class from the outside of the class
//static factory method-it provides the global point to access the singleton object and returns the instance of the caller
public class Singleton {
    public static void main(String[] args) {
        SingletonEarly singletonEarly=SingletonEarly.getObj();
        singletonEarly.singletonEarlyMethod();
        SingletonEarly.getObj().singletonEarlyMethod();

        SingletonLazy singletonLazy=SingletonLazy.getInstance();
        singletonLazy.singletonLazyMethod();
        SingletonLazy.getInstance().singletonLazyMethod();
    }
}
class SingletonEarly {
    private static SingletonEarly obj=new SingletonEarly();
    private SingletonEarly() {
    };
    public static SingletonEarly getObj() {
        return obj;
    }
    public void singletonEarlyMethod() {
        System.out.println("this is the singleton early");
    }
}
class SingletonLazy {
    private static SingletonLazy singletonLazy;
    private SingletonLazy() {

    }
    public static SingletonLazy getInstance() {
        if (singletonLazy==null){
            singletonLazy=new SingletonLazy();
        }
        return singletonLazy;
    }
    public void singletonLazyMethod() {
        System.out.println("this is the singleton lazy");
    }
}
