package org.selflearning.designpatterns.creational.factorymethod;

public class NotificationService {
    public static void main(String[] args) {
        NotificationFactory notificationFactory=new NotificationFactory();
        notificationFactory.createNotification("SMS").notifyUser();

    }
}
