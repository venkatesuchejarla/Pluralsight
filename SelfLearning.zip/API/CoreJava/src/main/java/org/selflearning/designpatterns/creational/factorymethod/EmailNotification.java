package org.selflearning.designpatterns.creational.factorymethod;

public class EmailNotification implements Notification {
    public void notifyUser() {
        System.out.println("Sending notification by Email");
    }
}
