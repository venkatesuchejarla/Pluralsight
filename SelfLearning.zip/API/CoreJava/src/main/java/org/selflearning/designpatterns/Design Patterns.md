# Creational Design Patterns;
### What;
Creational design patterns are used to create objects. 

### Why;
It reduces the complexity. 
It creates the objects in the controlled manaer.
We can create the objects with the new key word. But, some times nature of object must be changed according the nature of the program. 
Because, all the classes are tightly coupled, In such cases thease creational design patterns helps us.
Creational design patterns helps us to decouples the actual intiallization process.

### How;
1. Factory Pattern (or) Factory Method Design Pattern
2. Abstract Factory Pattern
3. Singleton Pattern
4. Prototype Pattern
5. Builder Pattern
6. Object Pool Pattern

## Factory Pattern (or) Factory Method Pattern;
### What;
Define an interface or abstract class.
It's sub classes will decide and responsible which class to instantiate.
It is also known as virtual constructor.
It hides the object creation logic from the client

### Why;
It allows the sub classes to choose the type of object to create.
It promotes loose coupling by eliminating the need to bind application-specific classes into the code.
That means the code interacts solely with the resultant interface or abstract class. So it will work with any classes that implements that interface or abstract class.

### When;
When a class doesn't know what sub classes will be required to create.
When a class wants that it sub classes specify the objects to be created.
When the parent class choose the creation of objects to it's sub classes.

### How;
Define a factory method inside an interface
Sub classes implement the factory method and decides which object to create

### Where
This design patterns are used in getInstance(), Etc.

### References;
1. javatpoint.com
2. geeksforgeeks.com


## Abstract Factory Pattern;


## Singleton Design Pattern;


## Prototype Design Pattern;


## Builder Design Pattern;
### What;
Construct a complex object from simple objects using step by step approach

### When;
It is mostly used when object can't be created in the single step like in the de-serialization of the complex object

### Why;
It provides clear separation between construction and representation of the object
It provides better control over construction process
It supports to change the internal representation of the object



## Object Pool Pattern;
### What;
To reuse the objects that are expensive to create
Object pool is a container it contains specified amount of objects
When an object is taken from the pool, it is not available in the pool until it is put it back.
Objects in the pool have a life cycle: creation, validation and destroy
Pool help to manage the objects in the better way

### Why;
It boots the performance of the application significantly
It is most effective, where the rate of intiallizing a class instance is high
It manages the connections and provides way to reuse and share them
It also provides the limit for the maximum number of objects that can be created

### When;
When we have a work to allocates or deallocates many objects
When we have a limited number of objects that will be in memory same time

### Where;
Data source pool, Thread pool




# Structural Design Patterns;
### What;
It simplify the design of large object structure by identifying relationships between them.
It provides common way of common way of composing, inheriting classes and objects so that they become repeatable
### How;
1. Adapter Design Pattern
2. Bridge Design Pattern
3. Composite Design Pattern
4. Decorator Design Pattern
5. Facade Design Pattern
6. Flyweight Design Pattern
7. Proxy Design Pattern


## Adapter Design Pattern
### What;
It act as a connector between two incompatible interfaces otherwise can't be connected directly.
It converts an existing interface into another interface that client expects.



## Bridge Design Pattern
### What;
It decouples the abstraction from the implementation. So that two can vary independently.
And hiding the implementation details from the client program.

## Composite Design Pattern
### What;
It allows client to operate the objects in the generic manner that may or may not represent a hierarchy of objects.



## Decorator Design Pattern
### What;
Dynamically add the functionality without affecting the functionality of other objects in the same class.
It uses composition instead of inheritance to extend the functionality of an object at run time.
It also know as wrapper.



## Facade Design Pattern
### What;
It encapsulate the complex sub system behind the simple iterface.
It hides the complexities of the sub system.
It provides the interface to the client using which the client can access the sub system.
It describes high level interface that makes the sub system easy to use.
Every abstract factory is the type of facade.


### Why;
It shields the client from the complexities of the sub system
It promotes loose coupling between sub system and client.

### When;
When you want to provide a simple interface to complex sub system.
When several dependencies exist between client and the implementation classes of an abstraction.


## Flyweight Design Pattern
### WHat;
Reuse the already existing similar kind of objects by stroring them. If not found create the new objects.

### Why;
It reuses the number of objects.
It reuses the amount of memory and storage devices required objects are persisted.

### When;
When the application uses the number of objects
When the storage cost is high because of the quantity of the objects.
When the application does not depend on object identity.



## Proxy Design Pattern
### What;
An object represnting another object.
Providing the control for accessing the original object.
It is also know as surrogate or place holder.

### Why
We can hide the information of original object.
It provides the protection of orginal object from the outside world.




# Behavioral Patterns;

The interaction between the objects should be in such a way that they can easily talk to each other and still should be loosely coupled.

That means the implementation and the client should be loosely coupled in order to avoid hard coding and dependencies.

There are 12 types of behavioral design patterns:

1. Chain of Responsibility Pattern
2. Command Pattern
3. Interpreter Pattern
4. Iterator Pattern
5. Mediator Pattern
6. Memento Pattern
7. Observer Pattern
8. State Pattern
9. Strategy Pattern
10. Template Pattern
11. Visitor Pattern
12. Null Object

## Chain of Responsibility Pattern;

### What;
Sender sends a request to a chain of objects. The request can be handled by any object in the chain.

Avoid coupling the sender of a request to its receiver by giving multiple objects a chance to handle the request.

Ex; ATM

Normally each receiver contains reference of another receiver. If one object cannot handle the request then it passes the same to the next receiver and so on.

### Why;

1. It reduces the coupling.
2. It adds flexibility while assigning the responsibilities to objects.
3. It allows a set of classes to act as one; events produced in one class can be sent to other handler classes with the help of composition.

### When;
1. When more than one object can handle a request and the handler is unknown.
2. When the group of objects that can handle the request must be specified in dynamic way.

### How;
1. Each processor in the chain will have its implementation for processing a command.
2. Every processor in the chain should have reference to the next processor.
3. Each processor is responsible for delegating to the next processor so beware of dropped commands.
4. Processors should not form a recursive cycle.
5. Only one processor in the chain handles a given command.

### Where;
In the Java world, we benefit from Chain of Responsibility every day. 
One such classic example is Servlet Filters in Java that allow multiple filters to process an HTTP request. Though in that case, each filter invokes the chain instead of the next filter.

### Dis-Advantages;

1. Mostly, it can get broken easily: If a processor fails to call the next processor, the command gets dropped. And if a processor calls the wrong processor, it can lead to a cycle
2. It can create deep stack traces, which can affect performance
3. It can lead to duplicate code across processors, increasing maintenance

### References;
1. javatpoint.com
2. baeldung.com
3. Daily Code Buffer - YouTube

## Command Pattern;

### What;
Encapsulate a request under an object as a command and pass it to invoker object. 
Invoker object looks for the appropriate object which can handle this command and pass the command to the corresponding object and that object executes the command.
It is also known as Action or Transaction.

## Interpreter Pattern;

### What;
To define a representation of grammar of a given language, along with an interpreter that uses this representation to interpret sentences in the language

## Iterator Pattern;

### What;

This pattern is used to get a way to access the elements of a collection object in sequential manner without any need to know its underlying representation.
