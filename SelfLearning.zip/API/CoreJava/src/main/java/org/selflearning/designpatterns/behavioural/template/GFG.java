package org.selflearning.designpatterns.behavioural.template;

public class GFG {
    public static void main(String[] args) {

    }
}
abstract class OrderProcessTemplate {

}
