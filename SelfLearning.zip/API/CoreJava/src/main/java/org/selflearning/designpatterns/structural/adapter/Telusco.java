package org.selflearning.designpatterns.structural.adapter;

public class Telusco {
    public static void main(String[] args) {

    }
}
interface Assignment {
    void write();
}
class Pen implements Assignment {
    @Override
    public void write() {
        System.out.println("Writing by pen");
    }
}
