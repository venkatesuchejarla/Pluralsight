package org.selflearning.designpatterns.behavioural.chainofresponsibility;
public class Payment {
    public static void main(String[] args) {
        PaymentHandler bank=new BankPaymentHandler();
        PaymentHandler creditCard=new CreditCardPaymentHandler();
        PaymentHandler upi=new UPIPaymentHandler();
        bank.setNext(creditCard);
        creditCard.setNext(upi);
        bank.handlePayment(200);
        bank.handlePayment(600);
        bank.handlePayment(1200);
    }
}
abstract class PaymentHandler {
    protected PaymentHandler next;

    public void setNext(PaymentHandler next) {
        this.next = next;
    }
    public abstract void handlePayment(double amount);
}
class BankPaymentHandler extends PaymentHandler {
    @Override
    public void handlePayment(double amount) {
        if (amount<=500)
            System.out.println("Paid using bank account "+amount);
        else
            next.handlePayment(amount);
    }
}
class CreditCardPaymentHandler extends PaymentHandler {
    @Override
    public void handlePayment(double amount) {
        if (amount<=1000)
            System.out.println("Paid using credit card "+amount);
        else
            next.handlePayment(amount);
    }
}
class UPIPaymentHandler extends PaymentHandler {
    @Override
    public void handlePayment(double amount) {
        if (amount<=1500)
            System.out.println("Paid using UPI "+amount);
        else
            next.handlePayment(amount);
    }
}