package org.selflearning.designpatterns.structural.flyweight;

import java.util.HashMap;

public class TP {
    private static final String colours[]={"Red","Blue","Yellow","Black","White"};
    public static void main(String[] args) {
    }
}
interface Shape {
    void draw();
}
class Circle implements Shape {
    String colour;
    int x;
    int y;
    int radius;
    public Circle(String colour) {
        this.colour=colour;
    }
    public void setX(int x) {
        this.x=x;
    }
    public void setY(int y) {
        this.y=y;
    }
    public void setRadius(int radius) {
        this.radius=radius;
    }

    @Override
    public void draw() {
        System.out.println("Colour is: "+colour+" X is: "+x+" Y is: "+y+" Radius: "+radius);
    }
}
class ShapeFactory {
    private static final HashMap circleMap=new HashMap();
    public static Shape getCircle(String colour) {
        Circle circle=(Circle)circleMap.get(colour);
        if (circle==null) {
            circle=new Circle(colour);
            circleMap.put(colour,circle);
            System.out.println("Creating circle of colour "+colour);
        }
        return circle;
    }
}