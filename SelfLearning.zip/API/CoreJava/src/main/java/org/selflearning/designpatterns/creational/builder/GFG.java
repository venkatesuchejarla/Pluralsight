package org.selflearning.designpatterns.creational.builder;

public class GFG {
    public static void main(String[] args) {

    }
}
interface HousePlan {
    public void setBasement(String basement);
    public void setStructure(String structure);
    public void setRoof(String roof);
    public void setInterior(String interior);
}
class House implements HousePlan {
    private String basement;
    private String structure;
    private String roof;
    private String interior;

    @Override
    public void setBasement(String basement) {
        this.basement = basement;
    }

    @Override
    public void setStructure(String structure) {
        this.structure = structure;
    }

    @Override
    public void setRoof(String roof) {
        this.roof = roof;
    }

    @Override
    public void setInterior(String interior) {
        this.interior = interior;
    }
}
interface HouseBuilder {
    public void buildBasement();
    public void buildStructure();
    public void buildRoof();
    public void buildInterior();
    public House getHouse();
}
class IglooBuilder implements HouseBuilder {
    private House house;
    public IglooBuilder() {
        this.house=new House();
    }
    @Override
    public void buildBasement() {
        house.setBasement("Ice Bars");
    }
    public void buildStructure() {
        house.setStructure("Ice Blocks");
    }
    public void buildInterior() {
        house.setInterior("Ice Carvings");
    }

    @Override
    public void buildRoof() {
        house.setRoof("Ice Dome");
    }

    public House getHouse() {
        return this.house;
    }
}