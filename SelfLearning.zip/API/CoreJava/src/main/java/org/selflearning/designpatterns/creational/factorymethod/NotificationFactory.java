package org.selflearning.designpatterns.creational.factorymethod;

public class NotificationFactory {
    public Notification createNotification(String chanel) {
        if (chanel == null || chanel.isEmpty())
            return null;
        switch (chanel) {
            case "SMS":
                return new SMSNotification();
            case "Email":
                return new EmailNotification();
            case "Push":
                return new PushNotification();
            default:
                throw new IllegalArgumentException("Unknown chanel " + chanel);
        }
    }
}
