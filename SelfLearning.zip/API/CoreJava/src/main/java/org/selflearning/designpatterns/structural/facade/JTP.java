package org.selflearning.designpatterns.structural.facade;

public class JTP {
    public static void main(String[] args) {
        ShopKeeper shopKeeper=new ShopKeeper();
        shopKeeper.iphoneSale();
        shopKeeper.samsungSale();
        shopKeeper.sonySale();
    }
}
interface MobileShop {
    public void modelNo();
    public void price();
}
class IPhone implements MobileShop {
    @Override
    public void modelNo() {
        System.out.println("I Phone 6");
    }

    @Override
    public void price() {
        System.out.println("65000");
    }
}
class Samsung implements MobileShop {
    @Override
    public void modelNo() {
        System.out.println("Samsung A7");
    }

    @Override
    public void price() {
        System.out.println("73000");
    }
}
class Sony implements MobileShop {
    @Override
    public void modelNo() {
        System.out.println("Sony X7");
    }

    @Override
    public void price() {
        System.out.println("55000");
    }
}
class ShopKeeper {
    private MobileShop iphone;
    private MobileShop samsung;
    private MobileShop sony;
    public ShopKeeper() {
        iphone=new IPhone();
        samsung=new Samsung();
        sony=new Sony();
    }
    public void iphoneSale() {
        iphone.modelNo();
        iphone.price();
    }
    public void samsungSale() {
        samsung.modelNo();
        samsung.price();
    }
    public void sonySale() {
        sony.modelNo();
        sony.price();
    }
}