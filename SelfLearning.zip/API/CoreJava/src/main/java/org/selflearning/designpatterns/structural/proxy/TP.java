package org.selflearning.designpatterns.structural.proxy;

public class TP {
    public static void main(String[] args) {
        Image image=new ProxyImage("image.png");
        image.display();
        System.out.println("************************");
        image.display();
    }
}
interface Image {
    void display();
}
class RealImage implements Image {
    String fileName;
    public RealImage(String fileName){
        this.fileName=fileName;
        loadFromDisk();
    }

    @Override
    public void display() {
        System.out.println("Displaying Image "+fileName);
    }
    private void loadFromDisk() {
        System.out.println("Loading "+fileName);
    }
}
class ProxyImage implements Image {
    private RealImage realImage;
    String fileName;
    public ProxyImage(String fileName){
        this.fileName=fileName;
    }

    @Override
    public void display() {
        if (realImage==null) {
            realImage=new RealImage(fileName);
        }
        realImage.display();
    }
}
