package com.selflearning.bean;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
//@JsonIgnoreProperties({"salary"})
@JsonFilter("Employee")
public class Employee {
    private Integer id;
    //@JsonIgnore
    private String name;
    private Long salary;
}
