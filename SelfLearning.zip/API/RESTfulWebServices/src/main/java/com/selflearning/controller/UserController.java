package com.selflearning.controller;

import com.selflearning.bean.User;
import com.selflearning.exception.UserNotFoundException;
import com.selflearning.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;
@RestController

public class UserController {
    @Autowired
    private UserService userService;
    @GetMapping("/users")
    public List<User> userList(){
        return userService.userList();
    }
    @GetMapping("/users/{id}")
    public User findOne(@PathVariable int id){
        User user = userService.findOne(id);
        if (user==null)
        throw new UserNotFoundException("id"+id);
        return user;
    }
    @DeleteMapping("/users/{id}")
    public void deleteById(@PathVariable int id) {
        User user = userService.deleteById(id);
        if (user==null) {
            throw new UserNotFoundException("id: "+id);
        }
    }
    @PostMapping("/users")
    public ResponseEntity<Object> save(@Valid @RequestBody User user){
        User savedUser = userService.save(user);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("{/id}").buildAndExpand(savedUser.getId()).toUri();
        return ResponseEntity.created(location).build();
    }
}
