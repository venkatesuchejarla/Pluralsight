package com.selflearning.controller;

import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import com.selflearning.bean.Employee;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class EmployeeController {
    @RequestMapping("/filtering/static")
    public Employee getStaticFilterEmployee() {
        return new Employee(100,"Venkatesu",10000L);
    }
    @RequestMapping("/filtering/dynamic")
    public MappingJacksonValue getDynamicFilterEmployee() {
        Employee employee=new Employee(101,"Mahi",2000L);
        SimpleBeanPropertyFilter filter=SimpleBeanPropertyFilter.filterOutAllExcept("name","salary");
        FilterProvider filterProvider=new SimpleFilterProvider().addFilter("Employee",filter);
        MappingJacksonValue mappingJacksonValue=new MappingJacksonValue(employee);
        mappingJacksonValue.setFilters(filterProvider);
        return mappingJacksonValue;
    }
}
