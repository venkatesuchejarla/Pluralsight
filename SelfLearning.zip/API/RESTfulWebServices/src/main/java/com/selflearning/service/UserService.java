package com.selflearning.service;

import com.selflearning.bean.User;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
@Component
public class UserService {
    public static int userCount=5;
    private static List<User> users=new ArrayList<>();
    static {
        users.add(new User(1,"venkatesu",new Date()));
        users.add(new User(2,"mahesh",new Date()));
        users.add(new User(3,"bharath",new Date()));
        users.add(new User(4,"jahn",new Date()));
        users.add(new User(5,"sow",new Date()));
    }
    public List<User> userList() {
        return users;
    }
    public User save(User user){
        if(user.getId()==null){
            user.setId(++userCount);
        }
        users.add(user);
        return user;
    }
    public User findOne(int id){
        for (User user:users) {
            if (user.getId()==id){
                return user;
            }
        }
        return null;
    }
    public User deleteById(int id){
        Iterator<User> iterator=users.iterator();
        while (iterator.hasNext()){
            User user=iterator.next();
            if (user.getId()==id){
                iterator.remove();
                return user;
            }
        }
        return null;
    }
}
