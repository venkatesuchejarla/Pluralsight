package com.selflearning.bean;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.boot.convert.DataSizeUnit;
import org.springframework.validation.annotation.Validated;

import java.util.Date;
@AllArgsConstructor
@Setter
@Getter
@ToString
public class User {
    private Integer id;
    @Size(min=5,message = "Name Should be at least 5 characteristics")
    private String name;
    @Past
    private Date dob;
}
