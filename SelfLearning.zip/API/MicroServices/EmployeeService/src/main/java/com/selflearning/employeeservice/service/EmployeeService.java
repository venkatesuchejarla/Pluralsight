package com.selflearning.employeeservice.service;

import com.selflearning.employeeservice.entity.Employee;
import com.selflearning.employeeservice.repository.EmployeeRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.Optional;

@Service
@Slf4j
public class EmployeeService {
    @Autowired
    private EmployeeRepository employeeRepository;

    public Employee saveEmployee(Employee employee) {
        log.info("Inside saveEmployee method of EmployeeService");
        return employeeRepository.save(employee);
    }

    public Optional<Employee> findUserById(Long employeeId) {
        return employeeRepository.findById(employeeId);
    }
}
