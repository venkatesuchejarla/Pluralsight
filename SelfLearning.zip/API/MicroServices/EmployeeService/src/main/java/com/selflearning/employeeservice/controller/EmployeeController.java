package com.selflearning.employeeservice.controller;

import com.selflearning.employeeservice.entity.Employee;
import com.selflearning.employeeservice.service.EmployeeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@Slf4j
@RequestMapping("/employees")
public class EmployeeController {
    @Autowired
    private EmployeeService employeeService;
    @PostMapping("/")
    public Employee saveEmployee(@RequestBody Employee employee) {
        log.info("Inside saveEmployee method of EmployeeController");
        return employeeService.saveEmployee(employee);
    }
    @GetMapping("/{id}")
    public Optional<Employee> findEmployeeById(@PathVariable("id") Long employeeId) {
        log.info("Inside findEmployeeById of UserController");
        return employeeService.findUserById(employeeId);
    }
}
