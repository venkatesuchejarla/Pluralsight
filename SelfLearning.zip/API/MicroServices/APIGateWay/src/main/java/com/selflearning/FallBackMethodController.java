package com.selflearning;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FallBackMethodController {
    @GetMapping("/employeeServiceFallBack")
    public String employeeServiceFallBack() {
        return "EmployeeService is taking longer than expected, Please try again later";
    }
    @GetMapping("/departmentServiceFallBack")
    public String departmentServiceFallBack() {
        return "DepartmentService is taking longer than expected, Please try again later";
    }
}
