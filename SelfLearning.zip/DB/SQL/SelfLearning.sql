#CREATE DATABASE
#CREATE DATABASE selflearning;

#USE DATABASE
#USE selflearning;
#SELECT * FROM selflearning.contact c;

#CREATE TABLE
#USE selflearning; CREATE TABLE contact (id INT, name VARCHAR(80), city VARCHAR(80),pincode INT, year INT);
#USE selflearning; CREATE TABLE contact (id INT NOT NULL, name VARCHAR(80), city VARCHAR(80),pincode INT, year INT);
#USE selflearning; CREATE TABLE contact (id INT PRIMARY KEY NOT NULL, name VARCHAR(80), city VARCHAR(80),pincode INT, year INT);
#USE selflearning; CREATE TABLE contact (CONSTRAINT id INT PRIMARY KEY NOT NULL, name VARCHAR(80), city VARCHAR(80),pincode INT, year INT);
#USE selflearning; ALTER TABLE contact ADD CONSTRAINT email FOREIGN KEY(id) REFERENCES contact(id);
#DROP TABLE contact;




#1. SELECT
#1A. SELECT with FROM CLAUSE
#SELECT name FROM contact;
#SELECT name, city FROM contact;
#SELECT * FROM contact;
#SELECT contact.name, contact.city, contact.pincode FROM contact;
#SELECT c.name, c.city, c.pincode FROM contact c;
#SELECT c.name as Name, c.city as City, c.pincode as PinCode FROM contact c;

#1B. SELECT with DISTINCT CLAUSE
#SELECT DISTINCT c.city, c.pincode FROM contact c;

#1C. SELECT with WHERE CLAUSE (we can check any boolean condition)
#SELECT c.name, c.pincode FROM contact c WHERE c.pincode=600097;
#SELECT c.name, c.pincode, c.year FROM contact c WHERE c.pincode=600097 AND c.year>1995;
#SELECT c.name, c.pincode FROM contact c WHERE c.pincode=524121 OR c.year>1995;
#SELECT c.name, c.year FROM contact c WHERE c.year BETWEEN 1995 AND 2000;
#SELECT c.name FROM contact c WHERE c.name LIKE 'M%';
#SELECT c.name FROM contact c WHERE c.name LIKE '%A%';
#SELECT c.name FROM contact c WHERE c.city IN ('Tirupati','Chennai');
#SELECT c.name FROM contact c WHERE c.city IS NULL;
#SELECT c.name FROM contact c WHERE c.city IS NOT NULL;

#1D. ORDER BY CLAUSE
#SELECT c.name FROM contact c ORDER BY name;
#SELECT COUNT(c.name) FROM contact c;
#SELECT MAX(c.year) FROM contact c;
#SELECT MIN(c.year) FROM contact c;
#SELECT AVG(c.year) FROM contact c;
#SELECT SUM(c.year) FROM contact c;
#SELECT COUNT(DISTINCT c.pincode) FROM contact c;
#SELECT COUNT(c.id), c.pincode FROM contact c GROUP BY c.pincode;
#SELECT COUNT(c.id), c.pincode FROM contact c GROUP BY c.pincode  HAVING COUNT(c.id) > 1;
#SELECT c.name, e.emailid FROM contact c, email e;
#SELECT c.name, c.city, e.emailid FROM contact c INNER JOIN email e ON c.name=e.name;
#SELECT c.name, c.city, e.emailid FROM contact c LEFT OUTER JOIN email e ON c.name=e.name;
#SELECT c.name, c.city, e.emailid FROM contact c RIGHT OUTER JOIN email e ON c.name=e.name;
#SELECT c.name, c.city, e.emailid FROM contact c LEFT OUTER JOIN email e ON c.name=e.name UNION DISTINCT SELECT c.name, c.city, e.emailid FROM contact c RIGHT OUTER JOIN email e ON c.name=e.name;



#2. INSERT
#INSERT INTO contact(name,city,pincode) VALUES('Mahesh','Sullurupeta','524121');
#INSERT INTO contact(id, name, city, pincode, year) VALUES ('6','Dhivya','Sullurupeta','524121','1994');
#INSERT INTO contact(id, name, city, pincode, year) VALUES(7,'Rajesh','Sullurupeta',524121,1990), (8,'Purvith','Sullurupeta',524121,2021);



#3. UPDATE
#UPDATE contact SET name='Mahesh' WHERE id=1;
#UPDATE contact c SET c.city='Andagundala' WHERE c.id=6;



#4. DELETE
#DELETE FROM contact WHERE id=2;
#DELETE FROM contact c WHERE c.id=7;