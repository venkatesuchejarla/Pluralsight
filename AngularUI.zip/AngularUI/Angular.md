# Angular;

## 1. Introduction;
### What & Why;
It is a framework it is used to build clientside applications.
It is used to develope the Single Page Applications, Where the parts of the view refreshed asynchronously without having to reload the entire page.
It is modular approach.
We can re-use the code.
It's developement quicker and easier.
It is unit testable.
It is provided by google and typeScript provided by the microsoft.

## 2. Getting Started;
### Prerequisites;
HTML, CSS, JS, TS.
### Development Environment;
Node, Npm, Angular CLI, Text editor-VS Code.
Instalation and version check node -version, npm -version, ng -v.

## 3. HelloWorld Application;
### Project Creation;
ng new helo-world : project creation.
cd hello-world : navigate inside the hello-world.
ng serve : to run the application.
localhost:4200 : hosting the running application with default address.
### Architecture;
Angular application is a collection of modules.
It will be imported and exported.
Every angular module contains the one root module that is the App-Module.
Each module contains a components and services.

Component; It controls the portion of the view on the browser. Ex; navigation, side bar, main content. 
Every angular application contains one root component it is the AppComponent. 
All other components will be neasted inside this AppComponent. 
Each component that contains the HTML to represnt the view in the browser and class that contains the logic to control the particular view.

Modules also contains the services, It is basically a class, It contains the bussiness logic of the application.

Summary; angular app -> one or more modules,
each module -> one or more components and services,
each component -> HTML + class (and) each service -> bussiness logic.

Modules export and import the code when required, finally render the view in the browser.

### Files;
package.json; This file contains the dependencies and dev dependencies which are nothing but libraries to develop the application.
All the packages that contains in the package.json is installed in the node_module folder.
Also it contains the scripts to start application.

src; It contains the main.ts file it is the entry point to our angular application
app; It contains the app.module.ts it is the root module for an application. And app.component.ts it is the root component for the application.

When we run the application, the execution will be, 
ng serve -> main.ts(in this file bootstrap and start the AppModule) -> app.module.ts(in this file bootstrap and start the AppComponent) -> app.component.ts(in this file it will go to the HTML + class) -> In the app.component.ts the class contains the property it is title and it is rendered to the app.component.html.

## 4. Components;
It is made up of 3 parts.
1. Template it represents the view. This is created using HTML. And it will be the UI for the application.
2. class it contains the code. It supports the view using TypeScript. It can be any other programming language, that contains the properties and methods to control the logic of the view.
3. metadata it contains the information to show the component it is the component or regular class. It is defined using the decorator. Decorator is function that provides the information about the class. And for component we use component decorator.

Ex; app.component.ts file contains the AppComponent class, It contains the one property that is title.
For this class metadata is attached into @Component decorator. It is basically function and attached to the AppComponent class.
As the part of @Component metadata, It contains the selector, templateUrl, styleUrls.
selector: It is HTML custom tag, It can be used to represent the AppComponent class. When we specify the selector in the HTML, angular renders that selector template in it's place.
app-root is used in the index.html file as a html custom tag.
templateUrl that points to html file that represents the view for this component. Class properties & methods binded to the html.
styleUrls that applies styles only to that component

### Creating new component;
ng g c component-name : creating the new component.
after creating the new component, the new component will be created inside the AppComponent.
4 new files will be created inside the new component component-name.component.ts, component-name.component.html, component-name.component.css, component-name.component.spec.ts.
In the app.module.ts, new component will be imported and added in the declaration array. declarations array it is an array it contains the all the components.
We can specifiy the selector in 3 ways;
1. We have to add the new component selector custom html tag in the app.component.html to render the view of new component html. Ex: Inside the app.component.html we have to use the custom html tag. i.e. <selector-name></selector-name>.
2. As a class, by begining the selector with the  . character we can use a selector as a class name. Ex: <div class="selector-name"></div>.
3. Enclose the selector in the []. Ex; <div selector-name></div>.

We can also specify the template in line in the component by using template tag instad of using templateUrl. We can specify the html in the template tag. Ex: <div>Inline template</div>. For multiple lines we have to use back ticks instad of using the single code.

We can also specify the styles in line in the component by using styles tag instad of using stylesUrl. We can specify the styles in the styles tag. Ex: `div {colour: red;}`

## 5. Interpolation;
It is for to bind the properties or functions from the class to template.
The message which we are displaying it will be static while we are using in the html. Ex: template: <h2>Welcome Venkatesu</h2>.
If we want the message dynamic. Ex: the message that may comes from webservices or the web api, the message may change at any point of time. 
For that we have to create the property or function inside the class.
In the case of data binding from the class to html we will use the {{}}. Inside it we will place the property or function which we have defined in the class.
In the interpolation assignments are not possible. Ex: {{a=2+2}}.
Can't access the global variables directly in the template. If we want to access it we have to create property for it inside the class. Then we have to bind it into the template.

## 6. Property Binding;
Attributes and Properties are not same.
Attributes defines by html. And the properties are defined by the document object model (DOM).
Attributes initialize DOM properties and then they are done. Attributes values can't change once they are initialized.
However property values can change.
HTML attributes value specifies the intial value. The DOM value property is the current value. So the value attribute remains the same where as the value property change.

In the property binding, we are binding the property to the DOM property not to html attribute.

Define the new property in the class. We need to bind this property to the html property element.
We have to enclose the html property with [] after we have assign that to class property. Ex: [name]="employeeName". 