import { Component } from '@angular/core';

@Component({
  selector: 'app-data-binding',
  templateUrl: './data-binding.component.html',
  styleUrls: ['./data-binding.component.css']
})
export class DataBindingComponent {
  public fullName="Venkatesu Chejarla";
  public myId="101";
  greatUser(){
    return "Hello "+this.fullName;
  }
}
